#!/usr/bin/env python3
"""
Enhanced SAP Catalog Integrator with License-Based Feature Management
Clearly separates Datasphere and Business Data Cloud capabilities
"""

import json
import logging
from datetime import datetime
from typing import Dict, Any
import boto3

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sap-catalog-integrator")

# License Detection (simplified for demo)
class LicenseManager:
    def __init__(self):
        self.datasphere_available = True  # Currently working
        self.bdc_available = False        # Not yet implemented
    
    def get_license_status(self):
        return {
            "datasphere": self.datasphere_available,
            "bdc": self.bdc_available,
            "license_type": "datasphere_only" if self.datasphere_available and not self.bdc_available else "full"
        }

license_manager = LicenseManager()

def create_html_response(title: str, content: str) -> Dict[str, Any]:
    """Create an HTML response with license-aware styling"""
    
    license_status = license_manager.get_license_status()
    
    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{title}</title>
        <style>
            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }}
            
            body {{
                font-family: 'Inter', 'Segoe UI', sans-serif;
                background: #0a0a0a;
                color: #e0e0e0;
                min-height: 100vh;
                background-image: 
                    radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                    radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%);
            }}
            
            .header {{
                background: rgba(26, 26, 26, 0.9);
                border-bottom: 1px solid rgba(120, 255, 119, 0.2);
                padding: 20px 0;
                backdrop-filter: blur(10px);
            }}
            
            .header-content {{
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }}
            
            .logo {{
                display: flex;
                align-items: center;
                gap: 15px;
            }}
            
            .logo div {{
                display: flex;
                flex-direction: column;
            }}
            
            .header h1 {{
                font-size: 1.8em;
                background: linear-gradient(135deg, #78ff77 0%, #ff77c6 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                margin: 0;
            }}
            

            
            .status-badge {{
                background: linear-gradient(135deg, #78ff77, #ff77c6);
                color: #000;
                padding: 8px 16px;
                border-radius: 20px;
                font-weight: 600;
                font-size: 0.8em;
            }}
            
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                padding: 40px 20px;
            }}
            
            .platform-section {{
                margin-bottom: 40px;
            }}
            
            .platform-header {{
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }}
            
            .platform-title {{
                font-size: 1.5em;
                font-weight: 600;
            }}
            
            .platform-title.datasphere {{
                color: #78ff77;
            }}
            
            .platform-title.bdc {{
                color: #ff77c6;
            }}
            
            .platform-status {{
                font-size: 0.9em;
                padding: 6px 12px;
                border-radius: 15px;
                font-weight: 500;
            }}
            
            .platform-status.available {{
                background: rgba(120, 255, 119, 0.1);
                color: #78ff77;
                border: 1px solid rgba(120, 255, 119, 0.3);
            }}
            
            .platform-status.unavailable {{
                background: rgba(255, 255, 255, 0.05);
                color: #888;
                border: 1px solid rgba(255, 255, 255, 0.1);
            }}
            
            .feature-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
            }}
            
            .feature-card {{
                background: rgba(26, 26, 26, 0.8);
                border-radius: 12px;
                padding: 25px;
                border: 1px solid rgba(255, 255, 255, 0.1);
                transition: all 0.3s ease;
                position: relative;
            }}
            
            .feature-card.available {{
                border-color: rgba(120, 255, 119, 0.3);
            }}
            
            .feature-card.available:hover {{
                transform: translateY(-5px);
                border-color: rgba(120, 255, 119, 0.5);
                box-shadow: 0 10px 30px rgba(120, 255, 119, 0.1);
            }}
            
            .feature-card.unavailable {{
                opacity: 0.6;
                border-color: rgba(255, 255, 255, 0.05);
            }}
            
            .feature-header {{
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 15px;
            }}
            
            .feature-card h3 {{
                font-size: 1.2em;
                margin-bottom: 10px;
                color: #e0e0e0;
            }}
            
            .license-badge {{
                font-size: 0.75em;
                padding: 4px 8px;
                border-radius: 10px;
                font-weight: 500;
            }}
            
            .license-badge.datasphere {{
                background: rgba(120, 255, 119, 0.1);
                color: #78ff77;
                border: 1px solid rgba(120, 255, 119, 0.3);
            }}
            
            .license-badge.bdc {{
                background: rgba(255, 119, 198, 0.1);
                color: #ff77c6;
                border: 1px solid rgba(255, 119, 198, 0.3);
            }}
            
            .feature-card p {{
                color: #c0c0c0;
                line-height: 1.6;
                margin-bottom: 20px;
            }}
            
            .btn {{
                display: inline-block;
                padding: 12px 24px;
                background: linear-gradient(135deg, #78ff77, #ff77c6);
                color: #000;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                transition: all 0.3s ease;
                border: none;
                cursor: pointer;
                font-size: 0.9em;
            }}
            
            .btn:hover {{
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(120, 255, 119, 0.3);
            }}
            
            .btn.disabled {{
                background: rgba(255, 255, 255, 0.1);
                color: #666;
                cursor: not-allowed;
                transform: none;
                box-shadow: none;
            }}
            
            .btn.secondary {{
                background: rgba(255, 119, 198, 0.2);
                color: #ff77c6;
                border: 1px solid rgba(255, 119, 198, 0.3);
            }}
            
            .upgrade-prompt {{
                background: rgba(255, 119, 198, 0.05);
                border: 1px solid rgba(255, 119, 198, 0.2);
                border-radius: 12px;
                padding: 25px;
                margin-top: 30px;
            }}
            
            .upgrade-prompt h4 {{
                color: #ff77c6;
                margin-bottom: 15px;
                font-size: 1.1em;
            }}
            
            .upgrade-prompt ul {{
                margin: 15px 0;
                padding-left: 20px;
                color: #c0c0c0;
            }}
            
            .upgrade-prompt li {{
                margin-bottom: 8px;
            }}
            
            .nav-links {{
                display: flex;
                gap: 20px;
                margin-bottom: 30px;
                flex-wrap: wrap;
            }}
            
            .nav-links a {{
                color: #c0c0c0;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 8px;
                background: rgba(26, 26, 26, 0.8);
                border: 1px solid rgba(255, 255, 255, 0.1);
                transition: all 0.3s ease;
            }}
            
            .nav-links a:hover {{
                color: #78ff77;
                border-color: rgba(120, 255, 119, 0.3);
                background: rgba(120, 255, 119, 0.05);
            }}
            
            .nav-links a.disabled {{
                opacity: 0.5;
                cursor: not-allowed;
            }}
            
            .nav-links a.disabled:hover {{
                color: #c0c0c0;
                border-color: rgba(255, 255, 255, 0.1);
                background: rgba(26, 26, 26, 0.8);
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <div class="header-content">
                <div class="logo">
                    <div>
                        <h1>SAP Data Integrator to AWS</h1>
                        <p style="font-size: 0.8em; color: #78ff77; margin: 0;">Powered by Ailien Studio</p>
                    </div>
                </div>
                <div class="status-badge">LIVE</div>
            </div>
        </div>
        
        <div class="container">
            {content}
        </div>
        
        <footer style="background: rgba(26, 26, 26, 0.9); border-top: 1px solid rgba(120, 255, 119, 0.2); padding: 20px 0; margin-top: 40px; text-align: center;">
            <div style="max-width: 1200px; margin: 0 auto; color: #c0c0c0;">
                <p style="margin: 0; font-size: 0.9em;">
                    Powered by <strong style="color: #78ff77;">Ailien Studio</strong> | 
                    <a href="mailto:contact@ailien.studio" style="color: #ff77c6; text-decoration: none;">contact@ailien.studio</a>
                </p>
                <p style="margin: 5px 0 0 0; font-size: 0.8em; color: #888;">
                    AILIEN LLC | 5830 E 2nd St, Ste 7000 #29127, Casper, Wyoming 82609 US
                </p>
            </div>
        </footer>
    </body>
    </html>
    """
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html',
            'Cache-Control': 'no-cache'
        },
        'body': html
    }

def handle_dashboard() -> Dict[str, Any]:
    """Handle dashboard request with license-aware content"""
    
    license_status = license_manager.get_license_status()
    
    # Datasphere features (always available if licensed)
    datasphere_section = """
    <div class="platform-section">
        <div class="platform-header">
            <h2 class="platform-title datasphere">SAP Datasphere</h2>
            <span class="platform-status available">Active</span>
        </div>
        
        <div class="feature-grid">
            <div class="feature-card available">
                <div class="feature-header">
                    <h3>Data Catalog</h3>
                    <span class="license-badge datasphere">Datasphere</span>
                </div>
                <p>Browse and manage your Datasphere assets including views, tables, and models.</p>
                <a href="/catalog" class="btn">Browse Catalog</a>
            </div>
            
            <div class="feature-card available">
                <div class="feature-header">
                    <h3>AWS Glue Integration</h3>
                    <span class="license-badge datasphere">Datasphere</span>
                </div>
                <p>Synchronize metadata to AWS Glue Data Catalog for seamless analytics integration.</p>
                <a href="/glue" class="btn">View Glue Tables</a>
            </div>
            
            <div class="feature-card available">
                <div class="feature-header">
                    <h3>Data Viewer</h3>
                    <span class="license-badge datasphere">Datasphere</span>
                </div>
                <p>Explore and sample data from your Datasphere assets with interactive previews.</p>
                <a href="/data" class="btn">View Data</a>
            </div>
            
            <div class="feature-card available">
                <div class="feature-header">
                    <h3>Sync Manager</h3>
                    <span class="license-badge datasphere">Datasphere</span>
                </div>
                <p>Manage synchronization between Datasphere and AWS with real-time progress tracking.</p>
                <a href="/sync" class="btn">Manage Sync</a>
            </div>
        </div>
    </div>
    """
    
    # BDC features (conditional based on license)
    if license_status['bdc']:
        bdc_section = """
        <div class="platform-section">
            <div class="platform-header">
                <h2 class="platform-title bdc">SAP Business Data Cloud</h2>
                <span class="platform-status available">Active</span>
            </div>
            
            <div class="feature-grid">
                <div class="feature-card available">
                    <div class="feature-header">
                        <h3>Data Products</h3>
                        <span class="license-badge bdc">BDC</span>
                    </div>
                    <p>Create and manage enterprise data products for cross-organizational sharing.</p>
                    <a href="/bdc/products" class="btn">Manage Products</a>
                </div>
                
                <div class="feature-card available">
                    <div class="feature-header">
                        <h3>Data Sharing</h3>
                        <span class="license-badge bdc">BDC</span>
                    </div>
                    <p>Securely share data across organizations with advanced access controls.</p>
                    <a href="/bdc/sharing" class="btn">Manage Shares</a>
                </div>
                
                <div class="feature-card available">
                    <div class="feature-header">
                        <h3>API Management</h3>
                        <span class="license-badge bdc">BDC</span>
                    </div>
                    <p>Publish and manage data APIs with automated documentation and rate limiting.</p>
                    <a href="/bdc/apis" class="btn">Manage APIs</a>
                </div>
                
                <div class="feature-card available">
                    <div class="feature-header">
                        <h3>Cross-Platform Lineage</h3>
                        <span class="license-badge bdc">BDC</span>
                    </div>
                    <p>Track data lineage across Datasphere, BDC, and AWS for complete visibility.</p>
                    <a href="/bdc/lineage" class="btn">View Lineage</a>
                </div>
            </div>
        </div>
        """
    else:
        bdc_section = f"""
        <div class="platform-section">
            <div class="platform-header">
                <h2 class="platform-title bdc">SAP Business Data Cloud</h2>
                <span class="platform-status unavailable">License Required</span>
            </div>
            
            <div class="feature-grid">
                <div class="feature-card unavailable">
                    <div class="feature-header">
                        <h3>Data Products</h3>
                        <span class="license-badge bdc">BDC Required</span>
                    </div>
                    <p>Create and manage enterprise data products for cross-organizational sharing.</p>
                    <button class="btn disabled" disabled>Requires BDC License</button>
                </div>
                
                <div class="feature-card unavailable">
                    <div class="feature-header">
                        <h3>Data Sharing</h3>
                        <span class="license-badge bdc">BDC Required</span>
                    </div>
                    <p>Securely share data across organizations with advanced access controls.</p>
                    <button class="btn disabled" disabled>Requires BDC License</button>
                </div>
                
                <div class="feature-card unavailable">
                    <div class="feature-header">
                        <h3>API Management</h3>
                        <span class="license-badge bdc">BDC Required</span>
                    </div>
                    <p>Publish and manage data APIs with automated documentation and rate limiting.</p>
                    <button class="btn disabled" disabled>Requires BDC License</button>
                </div>
                
                <div class="feature-card unavailable">
                    <div class="feature-header">
                        <h3>Cross-Platform Lineage</h3>
                        <span class="license-badge bdc">BDC Required</span>
                    </div>
                    <p>Track data lineage across Datasphere, BDC, and AWS for complete visibility.</p>
                    <button class="btn disabled" disabled>Requires BDC License</button>
                </div>
            </div>
            
            <div class="upgrade-prompt">
                <h4>Unlock Advanced Data Capabilities</h4>
                <p>Add SAP Business Data Cloud to your license for enterprise-grade data management:</p>
                <ul>
                    <li>Enterprise data product management and cataloging</li>
                    <li>Cross-organizational data sharing with governance</li>
                    <li>Automated API publishing and management</li>
                    <li>Advanced data lineage and impact analysis</li>
                    <li>Enhanced compliance and governance features</li>
                </ul>
                <a href="mailto:contact@ailien.studio?subject=BDC Integration Inquiry" class="btn secondary">
                    Contact Ailien Studio for BDC Integration
                </a>
            </div>
        </div>
        """
    
    content = datasphere_section + bdc_section
    
    return create_html_response("SAP Catalog Integrator Dashboard", content)

# Keep existing handlers but add license awareness
def handle_glue() -> Dict[str, Any]:
    """Handle Glue tables request - Datasphere feature"""
    
    license_status = license_manager.get_license_status()
    
    if not license_status['datasphere']:
        content = """
        <div class="nav-links">
            <a href="/">Dashboard</a>
        </div>
        
        <div class="feature-card unavailable">
            <h2>AWS Glue Integration</h2>
            <p>This feature requires an active SAP Datasphere license.</p>
            <a href="mailto:contact@ailien.studio?subject=Datasphere License" class="btn secondary">Contact Ailien Studio</a>
        </div>
        """
        return create_html_response("License Required", content)
    
    # Existing Glue functionality here
    try:
        glue_client = boto3.client('glue', region_name='us-east-1')
        response = glue_client.get_tables(DatabaseName='datasphere_ge230769')
        tables = response.get('TableList', [])
        
        nav_links = """
        <div class="nav-links">
            <a href="/">Dashboard</a>
            <a href="/data">Data Viewer</a>
            <a href="/sync">Sync Manager</a>
            <a href="/status">System Status</a>
        </div>
        """
        
        if not tables:
            content = nav_links + """
            <div class="feature-card">
                <h2>AWS Glue Tables</h2>
                <p>No tables found in the Glue catalog. Run synchronization to populate tables.</p>
                <a href="/sync" class="btn">Start Synchronization</a>
            </div>
            """
        else:
            table_html = ""
            for table in tables:
                columns = table.get('StorageDescriptor', {}).get('Columns', [])
                params = table.get('Parameters', {})
                
                table_html += f"""
                <div class="feature-card available">
                    <h4>{table.get('Name', 'Unknown')}</h4>
                    <p><strong>Description:</strong> {table.get('Description', 'N/A')}</p>
                    <p><strong>Columns:</strong> {len(columns)}</p>
                    <p><strong>Source Asset:</strong> {params.get('datasphere_label') or params.get('datasphere_asset', 'N/A')}</p>
                    <p><strong>Last Updated:</strong> {table.get('UpdateTime', 'N/A')}</p>
                    <div style="margin-top: 10px;">
                        <a href="/data/{table.get('Name')}" class="btn" style="font-size: 0.9em; padding: 8px 16px;">View Data</a>
                    </div>
                </div>
                """
            
            content = nav_links + f"""
            <div class="platform-section">
                <div class="platform-header">
                    <h2 class="platform-title datasphere">AWS Glue Tables</h2>
                    <span class="platform-status available">{len(tables)} Tables</span>
                </div>
                <div class="feature-grid">
                    {table_html}
                </div>
            </div>
            """
        
        return create_html_response("AWS Glue Tables", content)
        
    except Exception as e:
        logger.error(f"Error in handle_glue: {e}")
        content = f"""
        <div class="nav-links">
            <a href="/">Dashboard</a>
        </div>
        
        <div class="feature-card unavailable">
            <h2>Error Loading Glue Tables</h2>
            <p>Error: {str(e)}</p>
        </div>
        """
        return create_html_response("Error", content)

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """AWS Lambda handler with license awareness"""
    
    try:
        # Extract path from the event
        path = event.get('rawPath', event.get('path', '/'))
        method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')
        
        logger.info(f"Request: {method} {path}")
        
        # Handle different paths
        if path == '/' or path == '':
            return handle_dashboard()
        elif path == '/glue':
            return handle_glue()
        elif path == '/catalog':
            return handle_dashboard()  # For now, redirect to dashboard
        elif path.startswith('/bdc/'):
            # BDC features - check license
            license_status = license_manager.get_license_status()
            if not license_status['bdc']:
                content = """
                <div class="nav-links">
                    <a href="/">Dashboard</a>
                </div>
                
                <div class="upgrade-prompt">
                    <h4>Business Data Cloud License Required</h4>
                    <p>This feature requires an active SAP Business Data Cloud license.</p>
                    <a href="mailto:contact@ailien.studio?subject=BDC License Inquiry" class="btn secondary">Contact Ailien Studio</a>
                </div>
                """
                return create_html_response("License Required", content)
            else:
                # BDC functionality would go here
                content = """
                <div class="nav-links">
                    <a href="/">Dashboard</a>
                </div>
                
                <div class="feature-card available">
                    <h2>Business Data Cloud Feature</h2>
                    <p>BDC functionality coming soon...</p>
                </div>
                """
                return create_html_response("BDC Feature", content)
        else:
            # 404 for unknown paths
            content = """
            <div class="nav-links">
                <a href="/">Dashboard</a>
            </div>
            
            <div class="feature-card unavailable">
                <h2>Page Not Found</h2>
                <p>The requested page was not found.</p>
                <a href="/" class="btn">Go to Dashboard</a>
            </div>
            """
            return create_html_response("Page Not Found", content)
    
    except Exception as e:
        logger.error(f"Error in lambda_handler: {e}")
        content = f"""
        <div class="feature-card unavailable">
            <h2>Server Error</h2>
            <p>An error occurred: {str(e)}</p>
            <a href="/" class="btn">Go to Dashboard</a>
        </div>
        """
        return create_html_response("Server Error", content)

# For local testing
if __name__ == "__main__":
    test_event = {
        'rawPath': '/',
        'requestContext': {
            'http': {
                'method': 'GET'
            }
        }
    }
    
    result = lambda_handler(test_event, None)
    print("Status Code:", result['statusCode'])
    print("Content Type:", result['headers']['Content-Type'])
    print("Body length:", len(result['body']))